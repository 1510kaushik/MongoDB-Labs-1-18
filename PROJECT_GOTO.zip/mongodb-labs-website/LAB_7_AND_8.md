# Lab 7.1 · CTI schema and BSON audit

The fixture models the news, publishers, and indicator catalog displayed by [CTI Digest](https://ctidigest.com/). It uses fictional records and reserved example indicators. Run these commands against a lab MongoDB server.

```sh
mongosh mongodb://localhost:27017 --file lab7_queries.js
mongodump --uri mongodb://localhost:27017 --db cti_platform --out lab7_dump
```

| Relationship | Storage | Reason and possible embedded design |
| --- | --- | --- |
| Article → analyst summary | Embedded | Small point-in-time byline read with each article. |
| Article → tags | Embedded | Small scalar list scoped to each article. |
| Article → publisher | `source_id` reference | Independent publisher metadata appears on many articles. Embedding `source: {id, name, reliability}` would remove the lookup and copy each publisher rating to all articles. |
| Article → observed indicators | `ioc_ids` references | Reused indicators have independently reviewed assessments. Embedding `indicator_snapshot: [{id, type, value, assessment}]` removes the join when filtering by confirmed indicators. Bulk corrections must update many articles, indicator arrays grow and review snapshots may become stale. |

The included BSON fixture can also be restored with `mongorestore --uri mongodb://localhost:27017 lab7_dump` on an empty lab database. Encoded maximum sizes are 83 bytes (sources), 90 (indicators), 217 (articles), and 382 (embedded articles); the server-side audit prints both means and maxima.

Publisher reliability and indicator confirmation are separate decisions. The embedded activity selects articles by indicator assessment while retaining the publisher reference. The script calculates average and maximum BSON bytes in each collection, reports maximum as a percentage of the 16 MiB limit, and fails at 80% of that limit.

# Lab 7.2 · Working set

The [Annual Security Reports catalog](https://github.com/jacobdjwilson/awesome-annual-security-reports) supplies public report links. Generate 100,000 stable, approximately 2 KiB fixtures for the workload. The sync mode records previously unseen catalog links in a separate collection using their URL as identity.

```sh
mongosh mongodb://localhost:27017 --file lab7_seed_working_set.js
python monitor_and_scrape.py --samples 12 --sync
```

Random reads span the whole workload through the indexed ID. Log the initial and later interval hit estimates and the instance-wide bytes used divided by bytes configured. The logical collection size, cache occupancy, and interval hit estimate measure different things. WiredTiger counters cover all activity on that node. For a cold-versus-warm comparison, use a disposable instance and document its cache configuration and restart. The 200 MiB logical workload can fit comfortably in a default cache, so the exact trend depends on configuration.

# Labs 8.1 and 8.2 · Replica set

```sh
docker compose up -d
docker compose cp lab8_replica_set_commands.js mongo1:/tmp/lab8.js
docker compose exec mongo1 mongosh --quiet --file /tmp/lab8.js
docker compose exec mongo2 mongosh 'mongodb://localhost:27018/cti_replicated?directConnection=true&readPreference=secondary' --quiet --eval 'printjson(db.threat_alerts.findOne({_id:"replication-check"}))'
docker compose exec mongo3 mongosh 'mongodb://localhost:27019/cti_replicated?directConnection=true&readPreference=secondary' --quiet --eval 'printjson(db.threat_alerts.findOne({_id:"replication-check"}))'
docker compose run --rm lab-client replica_failover_reader.py
```

Use the replica set's current primary for `rs.stepDown(30)`. The reader identifies the connection that actually served each read. Use `rs.status()` after election to compare elected roles with the reader's timestamps. To try priorities, after the original primary is back and electable, choose the current primary and set its priority to 3. Set the intended secondary to 2 and the other to 1. Apply `rs.reconfig(cfg)` from the current primary, wait for the configuration to commit, then step down that primary. Predict the priority-2 member if both candidates remain healthy and similarly up to date. Record the observed result and optime evidence.

For the optional arbiter, run `docker compose --profile arbiter up -d mongo-arbiter` and execute `rs.addArb("mongo-arbiter:27020")` on the primary. An arbiter votes and stores no user data. Adding it to three voting data members gives four votes and raises election quorum from two to three. To demonstrate the odd-vote benefit, reconfigure one data-bearing secondary in this separate activity as nonvoting with `votes: 0, priority: 0`, giving two data votes plus the arbiter. Restore the three-data-voter configuration and remove the arbiter before Labs 9–10. Some arbiter configurations change the implicit default write concern, in which case set an explicit default with `setDefaultRWConcern` on the primary before reconfiguring and document the value.

## Running later labs on this replica set

Use `docker compose run --rm lab-client <script.py>` for scripts requiring replica-set discovery, because the replica set advertises Docker service names. Use a fresh terminal for the Lab 9.2 observer and write probe. Identify actual secondaries from `rs.status()`, then run `bash simulate_partition.sh SECONDARY_1 SECONDARY_2`. The first isolation lasts 30 seconds, then the two-secondary phase lasts another 30 seconds. Enter a fresh label at each write probe. Record the time members become unreachable, when a write concern error versus a primary selection error occurs, and when healthy secondaries catch up. A member can remain listed with health zero. During loss of quorum, primary-only reads can fail as well as writes; the observer requests primary-preferred reads.
