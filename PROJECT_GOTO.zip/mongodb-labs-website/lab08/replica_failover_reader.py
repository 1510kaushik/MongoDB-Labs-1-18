import argparse
import os
import time
from datetime import datetime, timezone

from pymongo import MongoClient, ReadPreference, monitoring
from pymongo.errors import PyMongoError


class ReadObserver(monitoring.CommandListener):
    def started(self, event):
        pass

    def failed(self, event):
        pass

    def succeeded(self, event):
        if event.command_name == "find":
            print(f"read served by {event.connection_id}", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--uri", default=os.getenv("MONGO_URI", "mongodb://localhost:27017/?replicaSet=rs0"))
    parser.add_argument("--samples", type=int, default=0, help="0 means continuous")
    args = parser.parse_args()
    with MongoClient(args.uri, read_preference=ReadPreference.PRIMARY_PREFERRED,
                     serverSelectionTimeoutMS=1500, event_listeners=[ReadObserver()]) as client:
        for sample in iter(int, 1) if not args.samples else range(args.samples):
            print(datetime.now(timezone.utc).isoformat(), end=" ", flush=True)
            try:
                print("sample:", client.cti_replicated.threat_alerts.find_one())
            except PyMongoError as exc:
                print(f"read failed: {type(exc).__name__}")
            print("primary:", client.primary, "secondaries:", sorted(client.secondaries), flush=True)
            time.sleep(1)


if __name__ == "__main__":
    main()
