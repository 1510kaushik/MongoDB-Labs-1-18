const config = {_id: "rs0", members: [
  {_id: 0, host: "mongo1:27017"}, {_id: 1, host: "mongo2:27018"},
  {_id: 2, host: "mongo3:27019"}
]};
try { rs.status(); } catch (error) {
  if (error.code !== 94) throw error;
  assert.commandWorked(rs.initiate(config));
}
for (let attempt = 0; attempt < 60; attempt++) {
  if (db.hello().isWritablePrimary) break;
  sleep(1000);
}
const uri = "mongodb://mongo1:27017,mongo2:27018,mongo3:27019/?replicaSet=rs0";
const client = new Mongo(uri);
const collection = client.getDB("cti_replicated").threat_alerts;
collection.replaceOne({_id: "replication-check"}, {_id: "replication-check", observed_at: new Date()},
  {upsert: true, writeConcern: {w: 3, wtimeout: 15000}});
printjson(client.getDB("admin").runCommand({replSetGetStatus: 1}).members.map(
  ({name, stateStr, health}) => ({name, stateStr, health})));
