#!/usr/bin/env bash
set -euo pipefail
: "${1:?Usage: bash simulate_partition.sh FIRST_SECONDARY [SECOND_SECONDARY]}"
case "$1" in mongo1|mongo2|mongo3) ;; *) exit 2 ;; esac
case "${2:-}" in ""|mongo1|mongo2|mongo3) ;; *) exit 2 ;; esac
[[ "$1" != "${2:-}" ]]
network=$(docker inspect -f '{{range $name, $value := .NetworkSettings.Networks}}{{$name}}{{end}}' "$1")
isolated=()
recover() {
  for node in "${isolated[@]}"; do
    docker network connect --alias "$node" "$network" "$node" || true
  done
}
trap recover EXIT
trap 'exit 130' INT TERM
for node in "${@}"; do
  docker exec "$node" mongosh --quiet --port "$(
    case "$node" in mongo1) echo 27017 ;; mongo2) echo 27018 ;; *) echo 27019 ;; esac
  )" --eval 'if (!db.hello().secondary) quit(1)'
done
docker network disconnect "$network" "$1"
isolated+=("$1")
echo "One secondary isolated at $(date -u +%FT%TZ). Run the write probe now."
sleep 30
if [[ -n "${2:-}" ]]; then
  docker network disconnect "$network" "$2"
  isolated+=("$2")
  echo "Both secondaries isolated at $(date -u +%FT%TZ). Run the write probe again."
  sleep 30
fi
echo "Reconnecting at $(date -u +%FT%TZ). Check member health and oplog catch-up."
