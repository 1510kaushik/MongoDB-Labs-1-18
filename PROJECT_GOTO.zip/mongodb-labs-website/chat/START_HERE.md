# Windows Threat Chat

Extract the entire ZIP, then double-click **Start_Windows_Threat_Chat.cmd** in the extracted folder. Keep its console window open while you use chat. If a browser tab is showing a temporary ZIP path, close that preview and use the tab opened by the launcher.

Run these commands from the extracted website directory in PowerShell:

    ollama pull llama3.2:3b
    python .\chat\server.py

Open http://127.0.0.1:8765/chat/. Start Ollama first if it is closed. The server supports a smaller model via the --model option, for example qwen2.5:1.5b after pulling that model. No API key is needed. The Windows host runs the assessment while Docker continues to serve the lab website and its database services.

Choose Assess this laptop, then ask what to investigate or how to verify a mitigation. The assistant groups observations and links to applicable exercises. The probes gather limited host evidence and suggest manual steps. No device setting is changed. Defender event counts cannot establish that an individual threat is resolved. This bundle includes the existing Labs 7–18; the chat links to them and does not ingest their benchmark fixtures as laptop evidence.

Ollama API: https://github.com/ollama/ollama/blob/main/docs/api.md
