#!/usr/bin/env bash
set -euo pipefail
compose=(docker compose -p lab13 -f docker-compose.lab13.yml)
"${compose[@]}" up -d
for attempt in {1..60}; do
  if "${compose[@]}" exec -T mongo1 mongosh --quiet --eval 'quit(db.hello().ok === 1 ? 0 : 1)'; then
    break
  fi
  sleep 1
done
"${compose[@]}" exec -T mongo1 mongosh --quiet --eval '
const state = db.hello();
if (!state.setName) assert.commandWorked(rs.initiate({_id:"rs0", members:[
  {_id:0,host:"mongo1:27017"}, {_id:1,host:"mongo2:27017"}, {_id:2,host:"mongo3:27017"}
]}));
'
echo 'Use mongosh inside the elected primary to create the first admin, then authenticate and check rs.status().'
