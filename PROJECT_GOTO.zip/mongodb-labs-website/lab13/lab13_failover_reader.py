"""Lab 13.1 uses the same observer with the authenticated replica-set URI."""
import os

from replica_failover_reader import main


if __name__ == "__main__":
    if not os.getenv("MONGO_URI"):
        raise SystemExit("Set MONGO_URI to the authenticated replica-set connection string")
    main()
