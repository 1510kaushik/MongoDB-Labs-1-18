const input = document.getElementById("benchmark-upload");
if (input) {
  input.addEventListener("change", async () => {
    const file = input.files[0];
    if (!file) return;
    const status = document.getElementById("benchmark-status");
    try {
      const data = JSON.parse(await file.text());
      if (!data.trials_seconds || typeof data.run !== "string") throw new Error("Load a Lab 18.1 results JSON file.");
      const median = values => {
        if (!Array.isArray(values) || values.length !== 10 ||
            !values.every(v => typeof v === "number" && Number.isFinite(v) && v > 0)) {
          throw new Error("Each operation must contain ten positive timing samples.");
        }
        const sorted = [...values].sort((a, b) => a - b);
        return (sorted[4] + sorted[5]) / 2;
      };
      const rows = ["Mongo", "Cassandra", "Neo4j"].map(name => {
        const stats = data.trials_seconds[name];
        if (!stats) throw new Error("One or more database result sets are missing.");
        const timings = ["history", "spread", "volume", "insert"].map(operation => median(stats[operation]));
        const row = document.createElement("tr");
        for (const value of [name === "Mongo" ? "MongoDB" : name,
          ...timings.map(t => (t * 1000).toFixed(3)), (1 / timings[3]).toFixed(1)]) {
          row.insertCell().textContent = value;
        }
        return row;
      });
      document.getElementById("benchmark-rows").replaceChildren(...rows);
      status.textContent = `Loaded ${data.kind} results for ${data.count} observations. Run ${data.run}.`;
    } catch (error) {
      status.textContent = error.message;
    }
  });
}
