const cti = db.getSiblingDB("cti_platform");
const seed = (collection, rows) => rows.forEach(row =>
  collection.replaceOne({_id: row._id}, row, {upsert: true}));
seed(cti.threat_sources, [
  {_id: "publisher-a", name: "Example CERT", reliability: "high"},
  {_id: "publisher-b", name: "Example research team", reliability: "unrated"}
]);
seed(cti.indicators, [
  {_id: "ioc-1", type: "domain", value: "example.invalid", assessment: "confirmed"},
  {_id: "ioc-2", type: "ipv4", value: "192.0.2.20", assessment: "unverified"}
]);
seed(cti.digest_articles, [
  {_id: "digest-1", title: "Example advisory", source_id: "publisher-a", ioc_ids: ["ioc-1"],
   author_summary: {name: "Analyst Desk", role: "Analyst"}, tags: ["advisory"]},
  {_id: "digest-2", title: "Example observation", source_id: "publisher-b", ioc_ids: ["ioc-1", "ioc-2"],
   author_summary: {name: "Research Desk", role: "Researcher"}, tags: ["observation"]}
]);
cti.digest_articles.aggregate([
  {$lookup: {from: "indicators", localField: "ioc_ids", foreignField: "_id", as: "indicator_snapshot"}},
  {$unset: "ioc_ids"},
  {$merge: {into: "digest_embedded", whenMatched: "replace"}}
]).toArray();
printjson(cti.digest_embedded.find({"indicator_snapshot.assessment": "confirmed"}).toArray());
for (const name of ["threat_sources", "indicators", "digest_articles", "digest_embedded"]) {
  const [stat] = cti.getCollection(name).aggregate([
    {$project: {bytes: {$bsonSize: "$$ROOT"}}},
    {$group: {_id: null, count: {$sum: 1}, avgBytes: {$avg: "$bytes"}, maxBytes: {$max: "$bytes"}}}
  ]).toArray();
  if (!stat || stat.maxBytes >= 0.8 * 16 * 1024 * 1024) throw Error("Size check failed: " + name);
  printjson({collection: name, ...stat, percentOfLimit: stat.maxBytes * 100 / (16 * 1024 * 1024)});
}
