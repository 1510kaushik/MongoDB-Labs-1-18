"""Measure interval cache activity while reading the Lab 7 working set."""
import argparse
import hashlib
import random
import re
import time
from datetime import datetime, timezone
from urllib.request import urlopen

from pymongo import MongoClient

CATALOG = "https://raw.githubusercontent.com/jacobdjwilson/awesome-annual-security-reports/main/README.md"


def sync_new_reports(collection):
    with urlopen(CATALOG, timeout=5) as response:
        markdown = response.read().decode("utf-8")
    added = 0
    for line in markdown.splitlines():
        if "|" not in line:
            continue
        for title, url in re.findall(r"\[([^\]]+)\]\((https?://[^\s)]+)\)", line):
            if not re.search(r"\b20\d{2}\b", line):
                continue
            result = collection.update_one(
                {"_id": hashlib.sha256(url.encode()).hexdigest()},
                {"$setOnInsert": {"title": title, "source_url": url,
                                  "first_seen": datetime.now(timezone.utc)}},
                upsert=True,
            )
            added += result.upserted_id is not None
    return added


def interval_hit_ratio(previous, current):
    requested = current["pages requested from the cache"] - previous["pages requested from the cache"]
    loaded = current["pages read into cache"] - previous["pages read into cache"]
    if requested <= 0 or loaded < 0:
        return None
    return max(0.0, 1 - loaded / requested)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--uri", default="mongodb://localhost:27017")
    parser.add_argument("--samples", type=int, default=6)
    parser.add_argument("--sync", action="store_true")
    args = parser.parse_args()
    with MongoClient(args.uri, serverSelectionTimeoutMS=5000) as client:
        database = client.cti_working_set
        if args.sync:
            try:
                print("New catalog links:", sync_new_reports(database.report_catalog))
            except OSError as exc:
                print("Catalog fetch failed:", exc)
        previous = client.admin.command("serverStatus")["wiredTiger"]["cache"]
        for _ in range(args.samples):
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                database.security_reports.find_one({"_id": random.randrange(100000)})
            current = client.admin.command("serverStatus")["wiredTiger"]["cache"]
            used, capacity = (current[key] for key in
                              ("bytes currently in the cache", "maximum bytes configured"))
            ratio = interval_hit_ratio(previous, current)
            hit = f"{ratio:.2%}" if ratio is not None else "n/a"
            print(f"Cache {used / 2**20:.1f}/{capacity / 2**20:.1f} MiB "
                  f"({used / capacity:.1%} occupied) | interval hit estimate {hit}", flush=True)
            previous = current


if __name__ == "__main__":
    main()
