const reports = db.getSiblingDB("cti_working_set").security_reports;
const crypto = require("crypto");
for (let start = 0; start < 100000; start += 1000) {
  const ops = Array.from({length: 1000}, (_, offset) => ({
    updateOne: {filter: {_id: start + offset}, upsert: true,
      update: {$setOnInsert: {title: "Annual security report workload fixture",
        catalog: "awesome-annual-security-reports",
        payload: crypto.randomBytes(1440).toString("base64")}}}
  }));
  reports.bulkWrite(ops, {ordered: false});
}
printjson(reports.aggregate([
  {$match: {_id: {$type: "number"}}}, {$project: {bytes: {$bsonSize: "$$ROOT"}}},
  {$group: {_id: null, count: {$sum: 1}, avgBytes: {$avg: "$bytes"}}}
]).toArray());
