// Run using mongosh --file against a fresh local mongod started with --auth.
const admin = db.getSiblingDB("admin");
const lab = db.getSiblingDB("cti_security_lab");
const users = [
  {user: "app_user_read", password: process.env.LAB12_READ_PASSWORD, role: "ordersReader"},
  {user: "app_user_write", password: process.env.LAB12_WRITE_PASSWORD, role: "ordersWriter"},
  {user: "staff_general", password: process.env.LAB12_STAFF_PASSWORD, role: "directoryReader"},
  {user: "hr_manager", password: process.env.LAB12_HR_PASSWORD, role: "hrReader"}
];
const adminPassword = process.env.LAB12_ADMIN_PASSWORD;
if (!adminPassword || users.some(user => !user.password)) throw Error("Set all five LAB12 password variables");
if (process.env.LAB12_BOOTSTRAP === "1") {
  admin.createUser({user: "siteAdmin", pwd: adminPassword, roles: ["root"]});
}
admin.auth("siteAdmin", adminPassword);
const scoped = (collection, actions) => ({resource: {db: lab.getName(), collection}, actions});
for (const [role, privilege] of [
  ["ordersReader", scoped("orders", ["find"])],
  ["ordersWriter", scoped("orders", ["find", "insert", "update", "remove"])],
  ["directoryReader", scoped("employees_public_view", ["find"])],
  ["hrReader", scoped("employees", ["find"])]
]) {
  if (!lab.getRole(role)) lab.createRole({role, privileges: [privilege], roles: []});
}
lab.orders.updateOne({_id: "sample"}, {$set: {status: "OPEN"}}, {upsert: true});
lab.employees.updateOne({_id: "employee-1"}, {$set: {name: "Demo Employee", salary: 75000}}, {upsert: true});
if (!lab.getCollectionNames().includes("employees_public_view")) {
  lab.createView("employees_public_view", "employees", [{$project: {salary: 0}}]);
}
for (const {user, password, role} of users) {
  if (!lab.getUser(user)) lab.createUser({user, pwd: password, roles: [role]});
}

function verify(account, checks) {
  const verification = new Mongo(process.env.LAB12_URI || "mongodb://127.0.0.1:27017");
  const database = verification.getDB(lab.getName());
  database.auth(account.user, account.password);
  checks(database);
}
function denied(action) {
  let code;
  try { action(); } catch (error) { code = error.code; }
  assert.eq(13, code, "Expected Unauthorized");
}
verify(users[0], database => {
  assert.eq(1, database.orders.aggregate([{$match: {_id: "sample"}}]).toArray().length);
  denied(() => database.orders.insertOne({_id: "reader-write"}));
});
verify(users[1], database => {
  database.orders.deleteOne({_id: "writer-check"});
  database.orders.insertOne({_id: "writer-check"});
  assert.eq(1, database.orders.updateOne({_id: "writer-check"}, {$set: {status: "CLOSED"}}).modifiedCount);
  assert.eq(1, database.orders.deleteOne({_id: "writer-check"}).deletedCount);
  denied(() => database.employees.findOne());
});
verify(users[2], database => {
  assert(!("salary" in database.employees_public_view.findOne({_id: "employee-1"})));
  denied(() => database.employees.findOne());
});
verify(users[3], database => assert.eq(75000, database.employees.findOne({_id: "employee-1"}).salary));
print("Lab 12.1 permissions and salary redaction verified");
