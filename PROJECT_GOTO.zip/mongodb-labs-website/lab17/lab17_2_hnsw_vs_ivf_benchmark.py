"""Compare local HNSW and IVF using the same FAISS runtime and exact baseline."""
import argparse
import csv
import time
from pathlib import Path

import faiss
import numpy as np


def benchmark(vectors, queries, threads=1):
    faiss.omp_set_num_threads(threads)
    vectors = np.ascontiguousarray(vectors, dtype="float32")
    queries = np.ascontiguousarray(queries, dtype="float32")
    faiss.normalize_L2(vectors)
    faiss.normalize_L2(queries)
    exact = faiss.IndexFlatIP(384)
    exact.add(vectors)
    truth = exact.search(queries, 20)[1]

    def measure(index, kind, construction, built, parameter, values):
        for value in values:
            settings = index.hnsw if kind == "HNSW" else index
            setattr(settings, parameter, value)
            index.search(queries[:1], 20)
            latencies, recalls = [], []
            for query, expected in zip(queries, truth):
                start = time.perf_counter()
                _, actual = index.search(query.reshape(1, -1), 20)
                latencies.append((time.perf_counter() - start) * 1000)
                recalls.append(len(set(actual[0]) & set(expected)) / 20)
            yield {
                "index": kind, "construction": construction, "query_parameter": parameter,
                "query_value": value, "build_seconds": built,
                "mean_ms": float(np.mean(latencies)), "recall_pct": float(100 * np.mean(recalls)),
            }

    for edges in (16, 32):
        for ef in (32, 64, 128, 256):
            started = time.perf_counter()
            index = faiss.IndexHNSWFlat(384, edges, faiss.METRIC_INNER_PRODUCT)
            index.hnsw.efConstruction = ef
            index.add(vectors)
            built = time.perf_counter() - started
            yield from measure(index, "HNSW", f"M={edges}, efConstruction={ef}",
                               built, "efSearch", (32, 64, 128, 256))
    for lists in (50, 100):
        started = time.perf_counter()
        index = faiss.IndexIVFFlat(faiss.IndexFlatIP(384), 384, lists, faiss.METRIC_INNER_PRODUCT)
        index.train(vectors)
        index.add(vectors)
        built = time.perf_counter() - started
        yield from measure(index, "IVF", f"nlist={lists}", built, "nprobe",
                           sorted({10, lists // 2, lists}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("corpus", type=Path, help="Text file with at least 5100 distinct sentences, one per line")
    parser.add_argument("--out", type=Path, default=Path("lab17_results"))
    args = parser.parse_args()
    sentences = list(dict.fromkeys(line.strip() for line in args.corpus.read_text(encoding="utf-8").splitlines()
                                   if line.strip()))
    if len(sentences) < 5100:
        parser.error("Provide 5000 distinct corpus sentences and 100 held-out query sentences")
    from sentence_transformers import SentenceTransformer
    import matplotlib.pyplot as plt

    rng = np.random.default_rng(17)
    subset = [sentences[i] for i in rng.choice(len(sentences), 5100, replace=False)]
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    matrix = model.encode(subset, normalize_embeddings=True)
    rows = list(benchmark(matrix[:5000], matrix[5000:]))
    args.out.mkdir(parents=True, exist_ok=True)
    with (args.out / "vector_benchmark.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for kind, construction in dict.fromkeys((r["index"], r["construction"]) for r in rows):
        group = [r for r in rows if (r["index"], r["construction"]) == (kind, construction)]
        plt.plot([r["mean_ms"] for r in group], [r["recall_pct"] for r in group],
                 marker=".", label=f"{kind} {construction}")
    plt.xlabel("Mean query latency (ms)")
    plt.ylabel("Recall@20 (%)")
    plt.legend(fontsize="x-small")
    plt.tight_layout()
    plt.savefig(args.out / "latency_recall.png", dpi=180)


if __name__ == "__main__":
    main()
