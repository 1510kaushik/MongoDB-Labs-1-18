"""
Lab 17.1 & Activity 17.1: Minimal RAG Pipeline with Sliding-Window Chunking
and Multi-Turn MongoDB Conversation Memory
"""
import argparse
import json
import time
import os
from datetime import datetime, timezone
from typing import List, Dict, Any
from pymongo import MongoClient
from pymongo.operations import SearchIndexModel
import voyageai
from openai import OpenAI

MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("DB_NAME", "rag_lab")
VOYAGE_API_KEY = os.getenv("VOYAGE_API_KEY", "<YOUR_VOYAGE_API_KEY>")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "<YOUR_OPENAI_API_KEY>")

def chunk_document(text: str, source: str, window_words: int = 100, overlap_words: int = 20) -> List[Dict[str, Any]]:
    words = text.split()
    step = max(1, window_words - overlap_words)
    chunks = []
    for i in range(0, len(words), step):
        segment = " ".join(words[i : i + window_words])
        if segment.strip():
            chunks.append({"text": segment, "source": source, "chunk_index": len(chunks)})
    return chunks


def ingest_threat_intel_docs(documents: List[Dict[str, str]]) -> int:
    all_chunks = []
    for doc in documents:
        all_chunks.extend(chunk_document(doc["content"], doc["source"], window_words=100, overlap_words=20))

    texts = [c["text"] for c in all_chunks]
    embeddings = vo_client.embed(texts, model="voyage-3", input_type="document").embeddings

    records = []
    for chunk, emb in zip(all_chunks, embeddings):
        records.append({
            "text": chunk["text"],
            "source": chunk["source"],
            "chunk_index": chunk["chunk_index"],
            "embedding": emb
        })

    if records:
        for row in records:
            docs_col.update_one({"source": row["source"], "chunk_index": row["chunk_index"]},
                                {"$set": row}, upsert=True)
    return len(records)


def retrieve_top_chunks(query: str, num_candidates: int = 20, limit: int = 3) -> List[Dict[str, Any]]:
    query_embedding = vo_client.embed([query], model="voyage-3", input_type="query").embeddings[0]
    pipeline = [
        {
            "$vectorSearch": {
                "index": "vector_index",
                "path": "embedding",
                "queryVector": query_embedding,
                "numCandidates": num_candidates,
                "limit": limit
            }
        },
        {
            "$project": {
                "_id": 0,
                "text": 1,
                "source": 1,
                "score": {"$meta": "vectorSearchScore"}
            }
        }
    ]
    return list(docs_col.aggregate(pipeline))


def get_recent_exchanges(user_id: str, max_exchanges: int = 5) -> List[Dict[str, str]]:
    msgs = list(
        conv_col.find({"user_id": user_id}, {"_id": 0, "role": 1, "content": 1})
        .sort([("timestamp", -1), ("_id", -1)])
        .limit(max_exchanges * 2)
    )
    msgs.reverse()
    return msgs


def save_exchange(user_id: str, user_query: str, assistant_reply: str) -> None:
    now = datetime.now(timezone.utc)
    conv_col.insert_many([
        {"user_id": user_id, "timestamp": now, "role": "user", "content": user_query},
        {"user_id": user_id, "timestamp": now, "role": "assistant", "content": assistant_reply}
    ])


def answer_with_rag(user_id: str, query: str) -> Dict[str, Any]:
    retrieved = retrieve_top_chunks(query, num_candidates=20, limit=3)
    history = get_recent_exchanges(user_id, max_exchanges=5)

    history_block = "\n".join([f"{m['role'].upper()}: {m['content']}" for m in history]) or "None"
    context_block = "\n\n".join([f"[{i+1}] ({c['source']}): {c['text']}" for i, c in enumerate(retrieved)])

    prompt = (
        f"Conversation History (Last 5 Exchanges):\n{history_block}\n\n"
        f"Answer based on these documents:\n{context_block}\n\n"
        f"User Question: {query}"
    )

    completion = llm_client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a Threat Intelligence analyst. Ground answers strictly in retrieved context."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.2
    )
    answer = completion.choices[0].message.content
    save_exchange(user_id, query, answer)
    return {"query": query, "retrieved_chunks": retrieved, "history_turns_used": len(history), "answer": answer}


def main():
    global docs_col, conv_col, vo_client, llm_client
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--user", default="demo")
    parser.add_argument("--query", action="append", required=True)
    parser.add_argument("--ingest", action="store_true", help="Seed the three demo documents and build the index")
    args = parser.parse_args()
    if not MONGO_URI or not os.getenv("VOYAGE_API_KEY") or not os.getenv("OPENAI_API_KEY"):
        parser.error("Set MONGO_URI, VOYAGE_API_KEY, and OPENAI_API_KEY")
    vo_client = voyageai.Client(api_key=os.environ["VOYAGE_API_KEY"])
    llm_client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    with MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000) as client:
        docs_col = client[DB_NAME].documents
        conv_col = client[DB_NAME].conversations
        conv_col.create_index([("user_id", 1), ("timestamp", -1), ("_id", -1)])
        if args.ingest:
            docs_col.create_index([("source", 1), ("chunk_index", 1)], unique=True)
            ingest_threat_intel_docs([
                {"source": "indicator-assessment", "content": "An indicator is an observable such as an IP address or domain. Incident responders assess how recently it was seen, whether the source has direct evidence, and whether the observable has legitimate uses. Confidence and severity are separate fields. Record a timestamp and evidence references so later analysts can review a decision."},
                {"source": "publisher-reliability", "content": "Reliability describes the publication source and may change over time. A reliable publisher can still report an unverified sighting. Compare observations from independent sources and track corroborating evidence separately from the source rating."},
                {"source": "incident-triage", "content": "During triage, preserve original observations and use timestamps to align activity across systems. A single sighting warrants review. Prioritize evidence matching internal assets and annotate assumptions so another responder can reproduce the assessment."},
            ])
            if not list(docs_col.list_search_indexes("vector_index")):
                dimensions = len(docs_col.find_one({}, {"embedding": 1})["embedding"])
                docs_col.create_search_index(SearchIndexModel(
                    name="vector_index", type="vectorSearch",
                    definition={"fields": [{"type": "vector", "path": "embedding",
                                             "numDimensions": dimensions, "similarity": "cosine"}]},
                ))
            deadline = time.monotonic() + 300
            while time.monotonic() < deadline:
                indexes = list(docs_col.list_search_indexes("vector_index"))
                if indexes and indexes[0].get("queryable"):
                    break
                time.sleep(2)
            else:
                raise TimeoutError("Atlas vector index did not become queryable within five minutes")
        for query in args.query:
            print(json.dumps(answer_with_rag(args.user, query), indent=2))


if __name__ == "__main__":
    main()
