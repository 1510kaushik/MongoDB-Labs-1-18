# MongoDB labs 7–18 website

Run `docker compose up --build -d` in this directory and open http://localhost:8080.
You can also use `python -m http.server 8080` or open `index.html` directly to view the static pages.
Each lab has its own folder, page, scripts, and instructions. The browser examples for Labs 7–17 are simulations. The results panels identify measured offline checks. The Compose database examples and Lab 18 benchmark run separately.

Use Docker Compose v2 and Python 3.12 for local database clients. Lab 13.2 needs Kubernetes. Lab 17.1 needs Atlas, an embedding key and an LLM key. Stop one lab's cluster before launching another using the same ports.
Read the per-lab website page for its commands. The original expanded guide is also included as a reference.

Run the capstone from Lab 18's page. Its included graph result uses a labeled synthetic fixture; the live latency table waits for actual benchmark JSON. Never place credentials or private datasets inside the static site tree.
