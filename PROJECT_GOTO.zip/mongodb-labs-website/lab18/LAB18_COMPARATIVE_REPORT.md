# Lab 18.1 comparative report

## Dataset and environment

Record collection date, newest and oldest observation, publishers, deduplication rules, database versions, hardware, deployment topology, client versions, and consistency settings. The default workload selects the 100,000 newest unique source/threat/target/timestamp observations in the requested date window. Input is JSON Lines with the keys below. Use stable per-publisher IDs and consistent target names. The runner accepts local exports and HTTPS URLs containing normalized JSONL.

```json
{"id":"report-123","source":"publisher","target":"example.invalid","observed":"2026-11-20T00:00:00Z"}
```

```sh
python lab18_comparative_benchmark.py --input publisher-a.jsonl --input publisher-b.jsonl --days 365
python lab18_comparative_benchmark.py --demo --count 1000 --out lab18_demo.json
```

Set `NEO4J_PASSWORD` to a local password of at least eight characters. To start fresh local services, run `docker compose -p lab18 -f docker-compose.lab18.yml up -d --wait`. Ensure ports 27017, 9042, and 7687 are available before starting. Alternatively, use existing services. Optional connection settings are `MONGO_URI`, `CASSANDRA_HOST`, `NEO4J_URI`, and `NEO4J_USER`; defaults address local database services. Each run gets a fresh identifier. The demo generates synthetic data. The feeds used for a graded run must supply the full recent corpus. Use the public collector in START_HERE.md, or supply an approved export. A live 100,000-record benchmark was not verified in the authoring environment.

## Schema and workload

| Operation | MongoDB | Cassandra | Neo4j |
| --- | --- | --- | --- |
| History | Source/time/id compound index and latest 20 | Source partition ordered by observation time and ID | Indexed source/time query with latest 20 |
| Target and spread | Distinct sources for an indexed target | Target partition with one entry per source | Match the target and traverse incoming observation relationships |
| Daily volume | Count by indexed day | Count inside a day partition | Count nodes indexed by day |
| Insert | Acknowledged observation write | Three denormalized projections using LOCAL_ONE | Transaction containing the observation and target relationship |

Spread measures independent publisher coverage of the same target. It does not establish transmission or causal propagation. The insert trial measures single-observation acknowledgment latency and reports reciprocal median latency as **sequential** throughput. Cassandra's cost includes three writes, which can complete independently. Ten trials per operation and backend appear in the JSON output. Correctness checks use the same in-memory result for the three read queries. The runner rotates backend order and reuses open connections. Document the single-source, single-target and single-day query samples when interpreting the results.

## Results

| Backend | History median ms | Spread median ms | Daily count median ms | Insert median ms | Sequential inserts/s |
| --- | ---: | ---: | ---: | ---: | ---: |
| MongoDB | Pending | Pending | Pending | Pending | Pending |
| Cassandra | Pending | Pending | Pending | Pending | Pending |
| Neo4j | Pending | Pending | Pending | Pending | Pending |

Record the command output and attach the JSON trial data. Explain how result size, index usage, consistency settings and denormalized writes affect the ranking. Base the deployment recommendation on the actual workload and measured results.
