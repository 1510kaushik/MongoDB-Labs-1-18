# Lab 18.2 · Comparative analysis

## Executive summary

Use MongoDB as the system of record for full threat observations, Cassandra for high-volume time-ordered access patterns known in advance, and Neo4j for community and relationship analysis. A small team can start with MongoDB and add the other stores when measured workload or graph requirements justify the operational cost. A dense community prioritizes analyst review. A false-positive determination still requires independent evidence and an adjudicated label.

## Methodology

Load the same 100,000 recent, normalized source/threat/target/time observations into each database. The four benchmark operations are recent history for a source, publisher spread for a target, a daily volume count, and serialized single-record insert throughput. Run each ten times per database, report medians, and retain the JSON samples. The same expected results are checked for all reads. Record dataset age, publisher distribution, cardinality, deployment topology, software, CPU, memory, storage, indexes, durability and consistency settings. Run a sensitivity test with high-volume publishers, cold and warmed caches, and production-like replication. Capture p95 and throughput at concurrent load when evaluating a production deployment.

## System architecture and schema

Normalized feeds go to the benchmark runner, which writes the same observation to all three stores. The graph activity gets co-occurrence edges from Neo4j, runs weighted Louvain community detection, and retrieves transaction counts, latest timestamps, and risk-score context from MongoDB. Use stable canonical threat IDs across feeds so edges join to the same threat identities.

| Store | Schema | Design trade-off |
| --- | --- | --- |
| MongoDB | Observation documents containing ID, source, target, observation time and day; indexes for source/time/ID, target/source and day. Separate transaction collection indexed by run and threat ID. | Flexible detail lookup and aggregations. Index maintenance adds write and storage cost. |
| Cassandra | History partitioned by run/source with time, threat ID, and observation key as clustering fields; spread by run/target; volume by run/day. | The query dictates its projection. Three writes per observation add amplification and require replay/reconciliation after partial failure. |
| Neo4j | Observation nodes with run/source/ID/time/day and a stable observation key linked to target nodes by observation relationships. | Expressive cross-target relationships. Group sizes, graph degree, and the size of projections materially affect cost. |

## Query performance and results

| Operation | MongoDB median | Cassandra median | Neo4j median |
| --- | --- | --- | --- |
| Threat history | Pending live run | Pending live run | Pending live run |
| Target and spread | Pending live run | Pending live run | Pending live run |
| Daily analytics | Pending live run | Pending live run | Pending live run |
| Insert latency and serialized inserts/s | Pending live run | Pending live run | Pending live run |

The archive includes a measured execution of the synthetic **graph fixture**. It contains seven weighted edges and produces two candidate communities. This verifies the detection logic only. The three live database services were unavailable in the build environment. Actual latency is produced by the Lab 18.1 benchmark and is also rendered in the website when its JSON is loaded.

## Developer ergonomics and operations

| Store | Development | Horizontal scaling | Backup and monitoring |
| --- | --- | --- | --- |
| MongoDB | BSON documents and aggregation are flexible; teach index design and explain plans. | Shard collections through mongos and choose a key based on distribution and query targeting. Each shard uses replica-set members for availability. | Use topology-aware consistent backups and tested restores. Monitor cache pressure, operations, replication lag and shard balance. |
| Cassandra | CQL is approachable; access-pattern-specific schemas and repair require specialist skills. | Partition ranges are distributed with consistent hashing and replicated with tunable consistency. Bucket large source or day partitions before scaling. | Coordinate snapshots and incremental backups, document restoration, and monitor compaction, repair, tombstones, partition skew and coordinator latency. |
| Neo4j | Cypher makes graph traversals explicit; modeling, profiling and memory sizing need graph expertise. | Primary replicas provide availability and secondaries scale reads. Multiple databases and newer sharding capabilities require explicit modeling and edition/version checks. | Test compatible online backups where licensed; monitor page cache, heap, query latency, replication and projected graph memory. |

## Scalability assessment

Planning assumptions: MongoDB 2 KiB indexed projection, Cassandra 3 KiB across its three projections, Neo4j 2 KiB graph projection per observation. Approximate aggregate on-disk bytes = count × factor × three copies × two for headroom. Backup retention is additional. Cassandra disk estimates include transient space as broad headroom, and actual compaction strategy may require more. Initial hardware below is a planning baseline, unrelated to measured throughput.

| Observations | MongoDB, aggregate | Cassandra, aggregate | Neo4j, aggregate | Initial sizing to test |
| --- | ---: | ---: | ---: | --- |
| 1 million | 11.4 GiB | 17.2 GiB | 11.4 GiB | 3 nodes per production store, 4 vCPU / 16 GiB RAM / 100 GiB SSD each. |
| 10 million | 114.4 GiB | 171.7 GiB | 114.4 GiB | Start with 3 nodes per store, 8 vCPU / 32 GiB RAM / 250 GiB SSD each. Check hot partitions, cache and backup windows. |
| 100 million | 1,144.4 GiB | 1,716.6 GiB | 1,144.4 GiB | Evaluate 2 MongoDB shards with 3 members each, 6 Cassandra nodes, and 3 Neo4j primaries with separate analytics resources as needed. Start with 16 vCPU / 64 GiB RAM / 1 TiB NVMe per node. Add config-server capacity and benchmark the graph memory footprint separately. |

Validate assumptions using actual bytes per record, read/write concurrency, retention, p95 latency, restore drills and failure tests. A 100M-observation graph can require filtering or time-bounded projection to fit in memory.

## Final recommendation by access pattern

Use MongoDB for canonical details and flexible cross-source daily analysis, Cassandra for sustained ingest and bounded source/time history when the workload supports precomputed projections, and Neo4j for relationship spread and multi-hop community queries. For target-to-publisher listing without traversal, MongoDB's indexed distinct query is the simpler baseline. Confirm the recommendation with measurements at your production consistency and availability requirements.

## References

- [MongoDB sharding architecture](https://www.mongodb.com/docs/manual/sharding/)
- [Cassandra partitioning and replication](https://cassandra.apache.org/doc/latest/cassandra/architecture/dynamo.html)
- [Cassandra repair](https://cassandra.apache.org/doc/stable/cassandra/managing/operating/repair.html)
- [Neo4j cluster topology](https://neo4j.com/docs/operations-manual/current/clustering/introduction/)
- [Neo4j online backup](https://neo4j.com/docs/operations-manual/current/backup-restore/online-backup/)
