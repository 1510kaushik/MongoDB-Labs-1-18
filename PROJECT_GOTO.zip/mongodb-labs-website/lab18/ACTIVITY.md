# Activity 18.1 · Graph-based analyst triage

After the benchmark, read its run identifier from the results JSON. Each graph edge represents a pair of canonical threat IDs observed on the same target and UTC day. Edge weight is the number of distinct target-day buckets in which both threats appeared. Only retain pairs recurring at least twice by default. Buckets with more than 50 distinct threats are excluded to reduce high-degree hub effects. The query caps the graph at 50,000 edges. Tune these thresholds and report their impact on coverage.

The Python runner clusters the Neo4j-derived weighted graph using seeded Louvain. A candidate contains three or more members, has internal edge density at least 0.6, and has greater internal than external edge weight. Cross-reference the community against the MongoDB `lab18.transactions` collection, using `run` and `threat_id`. The runner returns transaction counts, latest observation, and mean risk score. The benchmark does not generate real transaction evidence. Load your authorized evidence separately with the schema below, then use the same run ID and canonical threat IDs.

```javascript
db.getSiblingDB("lab18").transactions.createIndex({run: 1, threat_id: 1})
// Normalized transaction JSONL fields: run is added by the importer.
// {"transaction_id":"OBS-021","threat_id":"T101","observed":"2026-11-20T12:00:00Z","risk_score":0.72}
```

Unmatched threats have a zero count. Shared infrastructure may cause false associations. Use independent telemetry and labelled analyst decisions to evaluate precision and recall. The bundled synthetic result demonstrates the graph logic on known communities.

See [START_HERE.md](START_HERE.md) for the evidence import and graph commands.
