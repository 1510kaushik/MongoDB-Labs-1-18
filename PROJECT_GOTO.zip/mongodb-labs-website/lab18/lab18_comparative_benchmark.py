"""Load normalized threat observations and compare three databases."""
import argparse
from hashlib import sha256
import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import median
from time import perf_counter
from urllib.request import urlopen
from uuid import uuid4


@dataclass(frozen=True)
class Threat:
    id: str
    source: str
    target: str
    observed: str

    @property
    def key(self):
        return sha256(json.dumps([self.source, self.id, self.target, self.observed]).encode()).hexdigest()

    @property
    def day(self):
        return self.observed[:10]


def records(inputs, count, days, demo):
    now = datetime.now(timezone.utc)
    if demo:
        for i in range(count):
            group, position = divmod(i, 16)
            day, remainder = divmod(position, 8)
            time = now - timedelta(days=(group % max(1, days - 1)), seconds=remainder)
            if days > 1:
                time -= timedelta(days=day)
            yield Threat(f"demo-{group}-{remainder % 4}", f"publisher-{remainder % 4}",
                         f"target-{group}", time.isoformat(timespec="microseconds"))
        return

    seen = set()
    for entry in inputs:
        stream = (urlopen(entry, timeout=30) if entry.startswith("https://")
                  else Path(entry).open("rb"))
        with stream:
            for line in stream:
                if not line.strip():
                    continue
                row = json.loads(line)
                stamp = datetime.fromisoformat(row["observed"])
                if stamp.tzinfo is None:
                    raise ValueError("observed must include a UTC offset")
                stamp = stamp.astimezone(timezone.utc)
                threat = Threat(str(row["id"]), str(row["source"]), str(row["target"]),
                                stamp.isoformat(timespec="microseconds"))
                key = (threat.source, threat.id, threat.target, threat.observed)
                if now - timedelta(days=days) <= stamp <= now and key not in seen:
                    seen.add(key)
                    yield threat


def load_dataset(args):
    candidates = sorted(records(args.input, args.count, args.days, args.demo),
                        key=lambda row: (row.observed, row.source, row.id), reverse=True)
    selected = candidates[:args.count]
    if len(selected) != args.count or len({r.source for r in selected}) < 2:
        raise ValueError(f"Requested {args.count} recent observations across 2+ publishers. "
                         f"Found {len(selected)} observations across "
                         f"{len({r.source for r in selected})} publishers.")
    return selected


class Mongo:
    def __init__(self, uri, run):
        from pymongo import MongoClient, WriteConcern

        self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
        self.collection = self.client.lab18.get_collection(run, write_concern=WriteConcern(w=1))
        self.collection.create_index([("source", 1), ("observed", -1), ("id", 1), ("key", 1)])
        self.collection.create_index([("target", 1), ("source", 1)])
        self.collection.create_index("day")

    def insert(self, rows):
        self.collection.insert_many([{**asdict(r), "day": r.day, "key": r.key} for r in rows])

    def history(self, source):
        return [(r["id"], r["observed"]) for r in
                self.collection.find({"source": source}).sort([("observed", -1), ("id", 1), ("key", 1)]).limit(20)]

    def spread(self, target):
        return set(self.collection.distinct("source", {"target": target}))

    def volume(self, day):
        return self.collection.count_documents({"day": day})

    def close(self):
        self.client.close()


class Cassandra:
    def __init__(self, host, run):
        from cassandra import ConsistencyLevel
        from cassandra.cluster import Cluster, ExecutionProfile, EXEC_PROFILE_DEFAULT

        self.cluster = Cluster([host], execution_profiles={
            EXEC_PROFILE_DEFAULT: ExecutionProfile(consistency_level=ConsistencyLevel.LOCAL_ONE)})
        self.session = self.cluster.connect()
        self.session.execute("CREATE KEYSPACE IF NOT EXISTS lab18 WITH replication = "
                             "{'class':'SimpleStrategy', 'replication_factor':1}")
        self.session.set_keyspace("lab18")
        self.run = run
        definitions = {
            "history_v2": "(run text, source text, observed text, id text, obs_key text, PRIMARY KEY ((run, source), observed, id, obs_key)) "
                       "WITH CLUSTERING ORDER BY (observed DESC, id ASC, obs_key ASC)",
            "spread": "(run text, target text, source text, PRIMARY KEY ((run, target), source))",
            "volume_v2": "(run text, day text, obs_key text, PRIMARY KEY ((run, day), obs_key))",
        }
        for name, definition in definitions.items():
            self.session.execute(f"CREATE TABLE IF NOT EXISTS {name} {definition}")
        self.inserts = [
            self.session.prepare("INSERT INTO history_v2 (run, source, observed, id, obs_key) VALUES (?,?,?,?,?)"),
            self.session.prepare("INSERT INTO spread (run, target, source) VALUES (?,?,?)"),
            self.session.prepare("INSERT INTO volume_v2 (run, day, obs_key) VALUES (?,?,?)"),
        ]

    def insert(self, rows):
        from cassandra.concurrent import execute_concurrent

        params = [
            item for r in rows for item in (
                (self.inserts[0], (self.run, r.source, r.observed, r.id, r.key)),
                (self.inserts[1], (self.run, r.target, r.source)),
                (self.inserts[2], (self.run, r.day, r.key)),
            )
        ]
        execute_concurrent(self.session, params, concurrency=32, raise_on_first_error=True)

    def history(self, source):
        rows = self.session.execute("SELECT id, observed FROM history_v2 WHERE run=%s AND source=%s LIMIT 20",
                                    (self.run, source))
        return [(r.id, r.observed) for r in rows]

    def spread(self, target):
        return {r.source for r in self.session.execute("SELECT source FROM spread WHERE run=%s AND target=%s",
                                                       (self.run, target))}

    def volume(self, day):
        row = self.session.execute("SELECT COUNT(*) FROM volume_v2 WHERE run=%s AND day=%s", (self.run, day)).one()
        return row[0]

    def close(self):
        self.cluster.shutdown()


class Neo4j:
    def __init__(self, uri, user, password, run):
        from neo4j import GraphDatabase

        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.run = run
        self.query("CREATE INDEX lab18_history IF NOT EXISTS FOR (n:Lab18Threat) ON (n.run, n.source, n.observed)")
        self.query("CREATE INDEX lab18_day IF NOT EXISTS FOR (n:Lab18Threat) ON (n.run, n.day)")
        self.query("CREATE CONSTRAINT lab18_target IF NOT EXISTS FOR (n:Lab18Target) REQUIRE (n.run, n.name) IS UNIQUE")
        self.query("CALL db.awaitIndexes(60)")

    def query(self, cypher, **params):
        rows, _, _ = self.driver.execute_query(cypher, run=self.run, **params)
        return rows

    def insert(self, rows):
        self.query("""
            UNWIND $batch AS row
            MERGE (target:Lab18Target {run:$run, name:row.target})
            CREATE (event:Lab18Threat)
            SET event = row, event.run = $run
            CREATE (event)-[:LAB18_OBSERVED_ON]->(target)
        """, batch=[{**asdict(r), "day": r.day, "key": r.key} for r in rows])

    def history(self, source):
        return [(r["id"], r["observed"]) for r in self.query("""
            MATCH (e:Lab18Threat {run:$run, source:$source})
            RETURN e.id AS id, e.observed AS observed ORDER BY observed DESC, id ASC, e.key ASC LIMIT 20
        """, source=source)]

    def spread(self, target):
        return {r["source"] for r in self.query("""
            MATCH (e:Lab18Threat)-[:LAB18_OBSERVED_ON]->(:Lab18Target {run:$run, name:$target})
            RETURN DISTINCT e.source AS source
        """, target=target)}

    def volume(self, day):
        return self.query("MATCH (e:Lab18Threat {run:$run, day:$day}) RETURN count(e) AS n", day=day)[0]["n"]

    def close(self):
        self.driver.close()


def compare(backends, rows, run):
    source, target, day = rows[0].source, rows[0].target, rows[0].day
    history = sorted((r for r in rows if r.source == source), key=lambda r: (r.id, r.key))
    history.sort(key=lambda r: r.observed, reverse=True)
    cases = {
        "history": (source, [(r.id, r.observed) for r in history[:20]]),
        "spread": (target, {r.source for r in rows if r.target == target}),
        "volume": (day, sum(r.day == day for r in rows)),
    }
    for backend in backends:
        for start in range(0, len(rows), 500):
            backend.insert(rows[start:start + 500])

    timings = {type(backend).__name__: {key: [] for key in (*cases, "insert")} for backend in backends}
    for trial in range(10):
        for backend in backends[trial % 3:] + backends[:trial % 3]:
            stats = timings[type(backend).__name__]
            for name, (key, expected) in cases.items():
                begin = perf_counter()
                result = getattr(backend, name)(key)
                stats[name].append(perf_counter() - begin)
                if result != expected:
                    raise RuntimeError(f"{type(backend).__name__} returned incorrect {name} result")
            probe = Threat(f"{run}-probe-{trial}", "benchmark-probe", "benchmark-probe",
                           "1970-01-01T00:00:00+00:00")
            begin = perf_counter()
            backend.insert([probe])
            stats["insert"].append(perf_counter() - begin)
    return timings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", action="append", default=[], help="Normalized JSONL path or HTTPS URL")
    parser.add_argument("--demo", action="store_true", help="Use labeled synthetic observations")
    parser.add_argument("--count", type=int, default=100000)
    parser.add_argument("--days", type=int, default=365)
    parser.add_argument("--out", type=Path, default=Path("lab18_results.json"))
    args = parser.parse_args()
    if args.demo and args.days < 2:
        parser.error("Use a synthetic window of at least two days")
    if args.count < 2 or args.days < 1 or (args.demo == bool(args.input)):
        parser.error("Provide --demo or one or more --input values and positive count/window")
    data = load_dataset(args)
    run = "run_" + uuid4().hex
    from contextlib import ExitStack

    with ExitStack() as stack:
        backends = []
        for create in (
            lambda: Mongo(os.getenv("MONGO_URI", "mongodb://localhost:27017"), run),
            lambda: Cassandra(os.getenv("CASSANDRA_HOST", "localhost"), run),
            lambda: Neo4j(os.getenv("NEO4J_URI", "bolt://localhost:7687"),
                          os.getenv("NEO4J_USER", "neo4j"), os.environ["NEO4J_PASSWORD"], run),
        ):
            backend = create()
            stack.callback(backend.close)
            backends.append(backend)
        timings = compare(backends, data, run)
    print(f"Run ID: {run}")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    print("| Database | History ms | Spread ms | Daily volume ms | Insert ms | Sequential inserts/s |")
    print("| --- | ---: | ---: | ---: | ---: | ---: |")
    for name, stats in timings.items():
        summary = [median(value) for value in stats.values()]
        print(f"| {name} | " + " | ".join(f"{seconds * 1000:.3f}" for seconds in summary)
              + f" | {1 / summary[-1]:.1f} |")
    args.out.write_text(json.dumps({
        "run": run, "kind": "synthetic" if args.demo else "feed observations",
        "publishers": sorted({r.source for r in data}), "count": len(data),
        "window_days": args.days, "oldest": data[-1].observed, "newest": data[0].observed,
        "trials_seconds": timings,
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
