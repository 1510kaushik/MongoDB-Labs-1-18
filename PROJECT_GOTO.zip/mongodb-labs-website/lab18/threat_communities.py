"""Identify dense threat communities and enrich them with MongoDB evidence."""
import argparse
import json
import os
import re
from pathlib import Path

import networkx as nx


QUERY = """
MATCH (target:Lab18Target {run:$run})<-[:LAB18_OBSERVED_ON]-(event:Lab18Threat)
WITH target, event.day AS day, collect(DISTINCT event.id)[..51] AS candidates
WHERE size(candidates) >= 2 AND size(candidates) <= 50 AND day >= $since
UNWIND candidates AS left
UNWIND candidates AS right
WITH left, right WHERE left < right
WITH left, right, count(*) AS frequency
WHERE frequency >= $min_frequency
RETURN left, right, frequency
ORDER BY frequency DESC, left, right
LIMIT $edge_limit
"""


def communities(edges, transaction_counts, min_density=0.6):
    graph = nx.Graph()
    graph.add_weighted_edges_from(edges, weight="frequency")
    if graph.number_of_edges() == 0:
        return []
    output = []
    for members in nx.community.louvain_communities(graph, weight="frequency", seed=18):
        sub = graph.subgraph(members)
        if len(members) < 3 or nx.density(sub) < min_density:
            continue
        internal = int(sub.size(weight="frequency"))
        external = sum(weight for _, _, weight in nx.edge_boundary(
            graph, members, data="frequency", default=0))
        if internal <= external:
            continue
        ordered = sorted(members)
        output.append({
            "threats": ordered, "density": round(nx.density(sub), 3),
            "internal_frequency": internal, "external_frequency": external,
            "mongo_transactions_by_threat": {member: transaction_counts.get(member, 0) for member in ordered},
        })
    return sorted(output, key=lambda group: (-group["internal_frequency"], group["threats"]))


def live_data(args):
    from neo4j import GraphDatabase
    from pymongo import MongoClient

    with GraphDatabase.driver(os.getenv("NEO4J_URI", "bolt://localhost:7687"),
                               auth=(os.getenv("NEO4J_USER", "neo4j"), os.environ["NEO4J_PASSWORD"])) as driver:
        records, _, _ = driver.execute_query(QUERY, run=args.run, since=args.since,
                                              min_frequency=args.min_frequency, edge_limit=args.max_edges)
        edges = [(r["left"], r["right"], r["frequency"]) for r in records]
    members = {value for left, right, _ in edges for value in (left, right)}
    counts = {}
    with MongoClient(os.getenv("MONGO_URI", "mongodb://localhost:27017"), serverSelectionTimeoutMS=5000) as client:
        transactions = client.lab18.transactions
        for offset in range(0, len(members), 500):
            batch = sorted(members)[offset:offset + 500]
            for row in transactions.aggregate([
                {"$match": {"run": args.run, "threat_id": {"$in": batch}}},
                {"$group": {"_id": "$threat_id", "count": {"$sum": 1},
                            "last_observed": {"$max": "$observed"},
                            "risk_scores": {"$avg": "$risk_score"}}},
            ]):
                counts[row["_id"]] = {"count": row["count"], "last_observed": row["last_observed"],
                                      "mean_risk_score": row["risk_scores"]}
    return edges, counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--demo", action="store_true")
    source.add_argument("--run", help="Run identifier from the Lab 18.1 benchmark")
    parser.add_argument("--since", default="1970-01-01", help="UTC date in YYYY-MM-DD")
    parser.add_argument("--min-frequency", type=int, default=2)
    parser.add_argument("--max-edges", type=int, default=50000)
    parser.add_argument("--out", type=Path, default=Path("communities.json"))
    args = parser.parse_args()
    if args.run and not re.fullmatch(r"run_[a-f0-9]{32}", args.run):
        parser.error("Use the run identifier printed in the Lab 18.1 JSON output")
    if args.min_frequency < 1 or args.max_edges < 1:
        parser.error("Frequency and edge limits must be positive")
    from datetime import date
    try:
        date.fromisoformat(args.since)
    except ValueError:
        parser.error("Use a valid YYYY-MM-DD date")
    if args.demo:
        edges = [("T101", "T102", 8), ("T102", "T103", 7), ("T101", "T103", 6),
                 ("T201", "T202", 5), ("T201", "T203", 4), ("T202", "T203", 5),
                 ("T103", "T201", 2)]
        counts = {"T101": {"count": 4, "mean_risk_score": 0.72},
                  "T103": {"count": 2, "mean_risk_score": 0.35},
                  "T202": {"count": 1, "mean_risk_score": 0.23}}
    else:
        edges, counts = live_data(args)
    edges = [edge for edge in edges if edge[2] >= args.min_frequency][:args.max_edges]
    result = {"mode": "synthetic fixture" if args.demo else "Neo4j + MongoDB", "run": args.run,
              "evaluated_edges": len(edges), "edge_limit_reached": len(edges) == args.max_edges,
              "min_frequency": args.min_frequency, "communities": communities(edges, counts)}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(result, indent=2, default=str)
    args.out.write_text(payload + "\n", encoding="utf-8")
    print(payload)


if __name__ == "__main__":
    main()
