# Lab 18 capstone

## 18.1 · Build the comparative system

From this directory, set `NEO4J_PASSWORD` and start the three services.

```sh
docker compose -p lab18 -f docker-compose.lab18.yml up -d --wait
```

Collect public advisory metadata from NIST NVD and the GitHub Advisory Database. An NVD key and a GitHub token are optional. They raise API limits, and a full collection can take several minutes. See the sources below.

```sh
docker compose -p lab18 -f docker-compose.lab18.yml run --rm collector collect_public_feeds.py --days 365 --out /results
docker compose -p lab18 -f docker-compose.lab18.yml run --rm benchmark lab18_comparative_benchmark.py --days 365 --input /results/nvd.jsonl --input /results/github.jsonl --out /results/live-benchmark.json
```

The 100,000-row target counts source/target/time observations. A single advisory can describe multiple products. A CVE is a vulnerability advisory rather than evidence of a witnessed attack. Collectors preserve the canonical CVE/GHSA identifier, publisher, target and publication time. CPE products and ecosystem packages retain distinct namespaces because a reliable cross-source mapping requires a curated crosswalk. Prefer your approved CTI feeds if your course requires observed incidents instead of advisory records. Set `LAB18_INPUT_DIR` and use `/inputs/filename.jsonl` for those normalized files. The runner stops if it cannot find 100,000 recent observations from at least two sources in the selected corpus. It does not fill missing live records with synthetic data. Broaden the documented window or supply additional feeds if needed.

```json
{"id":"T101","source":"Verified publisher","target":"asset:example.invalid","observed":"2026-11-20T10:00:00Z"}
```

The benchmark stores the same corpus in MongoDB, Cassandra and Neo4j. It records ten timing samples for recent history, target/publisher spread, daily volume and a single acknowledged insert. The website reads the saved JSON and computes the median latency and sequential inserts per second. This is a local single-instance comparison. Cassandra uses LOCAL_ONE and writes three projections; the other databases use their lab acknowledgment path.

## Activity · Detect communities and cross-reference evidence

Use the run ID printed by the benchmark. Put your authorized transaction JSONL in the mounted input directory. The importer validates records and upserts on run, threat, and transaction.

```json
{"threat_id":"T101","transaction_id":"OBS-021","observed":"2026-11-20T10:02:00Z","risk_score":0.72}
```

```sh
docker compose -p lab18 -f docker-compose.lab18.yml run --rm benchmark import_transaction_evidence.py --run RUN_ID /inputs/transactions.jsonl
docker compose -p lab18 -f docker-compose.lab18.yml run --rm benchmark threat_communities.py --run RUN_ID --out /results/communities-live.json
```

Neo4j supplies co-occurrence weights. Weighted Louvain identifies dense groups. MongoDB supplies counts, the latest timestamp, and mean risk score for matching transaction evidence. Review each candidate against labeled analyst decisions before calling it a true or false positive. Use `ACTIVITY.md` for graph thresholds and limits.

## 18.2 · Comparative report

Open `REPORT.md` or read the report in the website. Attach the result JSON and replace the pending values with measured medians. The 1M, 10M and 100M entries are explicit sizing assumptions to validate against a production-like load test. 

Sources: [NVD API](https://nvd.nist.gov/developers/vulnerabilities) · [GitHub global security advisories](https://docs.github.com/en/rest/security-advisories/global-advisories)
