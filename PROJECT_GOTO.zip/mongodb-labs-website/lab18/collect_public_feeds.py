"""Collect public advisory metadata from NIST NVD and GitHub."""
import argparse
import json
import os
import re
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen


def fetch(url, headers):
    for attempt in range(4):
        try:
            with urlopen(Request(url, headers=headers), timeout=60) as response:
                return json.load(response), response.headers
        except HTTPError as error:
            if error.code not in {429, 500, 502, 503, 504} or attempt == 3:
                raise
            delay = error.headers.get("Retry-After", "")
            time.sleep(min(int(delay), 60) if delay.isdigit() else 2 ** attempt)
        except URLError:
            if attempt == 3:
                raise
            time.sleep(2 ** attempt)


def nvd_targets(cve):
    targets = set()
    stack = list(cve.get("configurations", []))
    while stack:
        node = stack.pop()
        stack.extend(node.get("nodes", []))
        for match in node.get("cpeMatch", []):
            if not match.get("vulnerable"):
                continue
            parts = re.split(r"(?<!\\):", match.get("criteria", ""))
            if len(parts) >= 5 and all(part not in {"*", "-"} for part in parts[3:5]):
                targets.add("cpe:" + ":".join(parts[3:5]).lower())
    return targets or {"unmapped:" + cve["id"]}


def nvd_records(start, end):
    key = os.getenv("NVD_API_KEY")
    headers = {"User-Agent": "MongoDB-Lab18/1.0", **({"apiKey": key} if key else {})}
    cursor = start
    endpoint = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    while cursor < end:
        upper = min(cursor + timedelta(days=119), end)
        offset = 0
        while True:
            params = urlencode({"pubStartDate": cursor.isoformat(timespec="milliseconds"),
                                "pubEndDate": upper.isoformat(timespec="milliseconds"),
                                "resultsPerPage": 2000, "startIndex": offset})
            payload, _ = fetch(endpoint + "?" + params, headers)
            batch = payload["vulnerabilities"]
            for item in batch:
                cve = item["cve"]
                if cve.get("vulnStatus") == "Rejected":
                    continue
                stamp = datetime.fromisoformat(cve["published"])
                stamp = stamp.replace(tzinfo=timezone.utc) if not stamp.tzinfo else stamp
                for target in sorted(nvd_targets(cve)):
                    yield {"id": cve["id"], "source": "NIST NVD", "target": target,
                           "observed": stamp.isoformat()}
            offset += len(batch)
            if offset >= payload["totalResults"]:
                break
            if not batch:
                raise RuntimeError("NVD pagination returned an empty page before all records were collected")
            time.sleep(0.7 if key else 6)
        cursor = upper + timedelta(milliseconds=1)
        if cursor < end:
            time.sleep(0.7 if key else 6)


def github_records(start, end):
    token = os.getenv("GITHUB_TOKEN")
    headers = {"User-Agent": "MongoDB-Lab18/1.0", "Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    url = "https://api.github.com/advisories?" + urlencode({
        "type": "reviewed", "published": f"{start.date()}..{end.date()}",
        "sort": "published", "direction": "desc", "per_page": 100,
    })
    while url:
        batch, response_headers = fetch(url, headers)
        for advisory in batch:
            if advisory.get("withdrawn_at"):
                continue
            threat = advisory.get("cve_id") or advisory["ghsa_id"]
            targets = {"package:" + package["ecosystem"].lower() + ":" + package["name"].lower()
                       for row in advisory.get("vulnerabilities", [])
                       if (package := row.get("package")) and package.get("name") and package.get("ecosystem")}
            for target in sorted(targets or {"unmapped:" + threat}):
                yield {"id": threat, "source": "GitHub Advisory Database", "target": target,
                       "observed": advisory["published_at"]}
        match = re.search(r'<([^>]+)>;\s*rel="next"', response_headers.get("Link", ""))
        url = match[1] if match else None
        if url and (urlparse(url).scheme, urlparse(url).netloc) != ("https", "api.github.com"):
            raise ValueError("Unexpected GitHub pagination destination")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--days", type=int, default=365)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--source", choices=("nvd", "github", "both"), default="both")
    args = parser.parse_args()
    if args.days < 1:
        parser.error("Use a positive collection window")
    args.out.mkdir(parents=True, exist_ok=True)
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=args.days)
    for name, collect in {"nvd": nvd_records, "github": github_records}.items():
        if args.source not in {name, "both"}:
            continue
        output = args.out / f"{name}.jsonl"
        partial = output.with_suffix(".jsonl.partial")
        count = 0
        with partial.open("w", encoding="utf-8") as handle:
            for row in collect(start, end):
                handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                count += 1
        partial.replace(output)
        print(f"{name}: saved {count:,} advisory observations to {output}")


if __name__ == "__main__":
    main()
