"""Load authorized transaction evidence into the MongoDB capstone collection."""
import argparse
import hashlib
import json
import math
import os
import re
from datetime import datetime, timezone
from pathlib import Path

from pymongo import MongoClient, ReplaceOne


def evidence_records(stream, run):
    for number, line in enumerate(stream, 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            threat = row["threat_id"]
            transaction = row["transaction_id"]
            observed = datetime.fromisoformat(row["observed"])
            risk = float(row["risk_score"])
            if not all(isinstance(x, str) and x.strip() for x in (threat, transaction)):
                raise ValueError("Expected nonempty threat_id and transaction_id")
            if observed.tzinfo is None or not math.isfinite(risk) or not 0 <= risk <= 1:
                raise ValueError("Expected an offset-aware timestamp and a risk score between 0 and 1")
            key = hashlib.sha256(json.dumps([run, threat, transaction]).encode()).hexdigest()
            yield {"_id": key, "run": run, "threat_id": threat,
                   "transaction_id": transaction, "observed": observed.astimezone(timezone.utc),
                   "risk_score": risk}
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Invalid evidence on line {number}: {exc}") from exc


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()
    if not re.fullmatch(r"run_[a-f0-9]{32}", args.run):
        parser.error("Use the run ID from the benchmark")
    with args.input.open(encoding="utf-8-sig") as stream:
        rows = list(evidence_records(stream, args.run))
    if not rows:
        parser.error("Provide at least one transaction record")
    with MongoClient(os.getenv("MONGO_URI", "mongodb://localhost:27017"), serverSelectionTimeoutMS=5000) as client:
        collection = client.lab18.transactions
        collection.create_index([("run", 1), ("threat_id", 1)])
        for start in range(0, len(rows), 500):
            collection.bulk_write([ReplaceOne({"_id": row["_id"]}, row, upsert=True)
                                   for row in rows[start:start + 500]])
    print(f"Processed {len(rows)} evidence rows for {args.run}.")


if __name__ == "__main__":
    main()
