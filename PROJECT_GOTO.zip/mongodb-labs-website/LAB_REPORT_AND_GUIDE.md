# MongoDB lab guide · Labs 7–18

Start with [Labs 7 and 8](LAB_7_AND_8.md). Run commands from the extracted project directory. The performance examples retained in this guide are illustrative. Record actual results from your environment.

## Lab 9.1: Measure Write Concern Latency & Activity 9.1 (Journaling)

### How to Run
With your 3-node replica set (`rs0`) running from Chapter 8:
```bash
docker compose run --rm lab-client write_concern_benchmark.py
```

### Benchmark Results & Latency Comparison Table (1,000 Sequential Single-Document Inserts)

| Write Concern Configuration | Total Time (1,000 writes) | Avg Latency / Write | Relative Speed | Durability & Replication Behavior |
| :--- | :---: | :---: | :---: | :--- |
| **`w:1, j:false`** | ~0.62 s | ~0.62 ms | **1.0x (Fastest)** | Returns immediately once Primary writes to in-memory WiredTiger cache. No disk flush wait; no secondary wait. |
| **`w:1, j:true`** | ~2.45 s | ~2.45 ms | ~3.9x slower | Primary must flush the WiredTiger journal (`fsync`) to disk before acknowledging. |
| **`w:majority, j:false`** | ~1.58 s | ~1.58 ms | ~2.5x slower | Primary writes to memory + replicates oplog over network to at least 1 Secondary's memory. |
| **`w:majority, j:true`** | ~3.60 s | ~3.60 ms | ~5.8x slower | Primary + at least 1 Secondary must apply the write AND flush their on-disk journals. |
| **`w:all` (`w:3`), `j:false`** | ~2.15 s | ~2.15 ms | ~3.5x slower | Waits for **every** data-bearing node (`mongo1`, `mongo2`, `mongo3`) to acknowledge; bounded by the slowest node. |
| **`w:all` (`w:3`), `j:true`** | ~4.40 s | ~4.40 ms | ~7.1x slower | Highest durability guarantee; waits for all 3 nodes to write and flush journals to disk. |

### Activity 9.1 Answer: Does Journaling (`j:true`) Add Significant Latency?
Compare journal-on and journal-off results from the same device. Enabling `j:true` forces MongoDB to wait for a physical disk `fsync` of the WiredTiger write-ahead journal (which normally groups commits every ~50–100 ms in the background when `j:false`). For sequential single-document inserts, `j:true` typically adds **1.5 ms to 2.5 ms per operation** (increasing total runtime by **2x–4x** depending on host SSD IOPS).

---

## Lab 9.2: Simulate a Network Partition

### Step-by-Step Execution
1. **Terminal 1 (Failover Observer from Lab 8.2):**
   ```bash
   python replica_failover_reader.py
   ```
2. **Terminal 2 (Isolate Secondary Nodes via Docker Network):**
   ```bash
   docker ps
   # Find network name (usually foldername_mongo_rs_net)
   docker network ls
   # Disconnect 1st secondary (mongo3)
   docker network disconnect <network_name> mongo3
   ```
3. **Terminal 3 (Test `w:1` vs `w:majority` Writes):**
   ```bash
   python network_partition_test.py
   ```
4. **Disconnect 2nd Secondary (`mongo2`) & Observe Step-Down:**
   ```bash
   docker network disconnect <network_name> mongo2
   ```
5. **After 30 Seconds, Reconnect Both Secondaries:**
   ```bash
   docker network connect <network_name> mongo3
   docker network connect <network_name> mongo2
   ```

### Example timeline and expected outcomes
- **T+0s (Healthy Cluster):** `mongo1` (`PRIMARY`), `mongo2` (`SECONDARY`), `mongo3` (`SECONDARY`). Quorum = 2 of 3. Both `w:1` and `w:majority` succeed.
- **T+5s (1 Secondary Partitioned — `mongo3` disconnected):** `mongo3` becomes unreachable (`health: 0`). Because `mongo1` + `mongo2` still hold **2 of 3 votes (majority)**, `mongo1` remains `PRIMARY`. Both `w:1` and `w:majority` inserts **succeed**.
- **T+15s (2nd Secondary Partitioned — `mongo2` disconnected):** `mongo1` is completely isolated (only **1 of 3 votes**).
  - Any `w:majority` write **times out** (`WriteConcernError: waiting for replication timed out`) because no majority exists.
  - Within ~10 seconds (missed election heartbeat timeout), `mongo1` detects it cannot see a majority and **automatically steps down to `SECONDARY`**, rendering the cluster **read-only** (even `w:1` writes now fail with `NotWritablePrimary`).
- **T+35s (Partition Healed — `mongo2` & `mongo3` reconnected):** Nodes re-establish heartbeats, trigger a fresh replica set election (~2–5 seconds), elect a new `PRIMARY` (highest priority / most up-to-date optime), and sync any missing oplog entries so all members return to `SECONDARY`/`PRIMARY` with `health: 1`.

---

## Lab 10.1: Implement a Bank Transfer Transaction & Activity 10.1 (Exponential Backoff)

### How to Run
```bash
docker compose run --rm lab-client bank_transfer_tx.py
```

### Implementation Highlights
- **Collections:** `accounts` (`{account_id, holder, balance, version}`) and `transfer_history` (`{tx_id, from_account, to_account, amount, status, timestamp}`).
- **Atomic Debit & Credit:** Uses `client.start_session()` and `session.start_transaction(write_concern=WriteConcern(w="majority"))` to verify source balance, update both accounts with `{"balance": {"$gte": amount}}` and `$inc` on `balance` and `version`, and insert the history log.
- **Rollback on Insufficient Funds:** Raising `ValueError` (or matching `0` documents on the conditional `$gte` debit) aborts the transaction so neither balance nor `transfer_history` changes.
- **Activity 10.1 Retry Logic:** Catches `PyMongoError` with `exc.has_error_label("TransientTransactionError")` and sleeps with exponential backoff `time.sleep(0.1 * (2 ** attempt))`.

---

## Lab 10.2: Inventory Reservation with Deadlock Handling & Throughput Comparison

### How to Run
```bash
docker compose run --rm lab-client inventory_reservation_tx.py
```

### Implementation Highlights
- **Schemas:** `inventory` (`{product_id, name, stock, version}`) and `orders` (`{order_id, customer_id, items, status, total}`).
- **Contention & Retry Loop:** With `stock: 5` and `8` concurrent `ThreadPoolExecutor` workers requesting `1` unit each, optimistic concurrency (`version` + `stock >= qty`) and retry loops (`time.sleep(0.02 * (attempt + 1))` up to 5 attempts) resolve write conflicts so exactly **5** reservations succeed and **3** fail cleanly once stock reaches `0`.
- **Concurrency & Non-Transactional Comparison (`1, 4, 8, 16` threads):**

| Concurrency (Threads) | Multi-Doc Transaction (`start_transaction`) | Non-Transactional (`findAndModify` + Insert) | Contention & Consistency Notes |
| :---: | :---: | :---: | :--- |
| **1** | Baseline throughput | Higher raw throughput | Minimal contention; transaction carries session/commit overhead. |
| **4** | Increases throughput | Scales with worker pool | Parallelism outweighs lock/conflict overhead. |
| **8** | Near peak / rising throughput | Higher throughput | Write conflicts on hot product doc trigger retries in TX mode. |
| **16** | Plateaus or dips | Higher raw throughput, **non-atomic** | Lock/write contention degrades TX scaling; non-TX risks orphan stock decrements if order insert fails. |

---

## Lab 11.1: Evaluate Shard Key Choices & Activity 11.1 (MongoDB 5.0+ Resharding)

### 1. E-Commerce Order Management Shard Key Decision Matrix

| Candidate Shard Key | Cardinality | Write Distribution | Query Targeting | Verdict & Justification |
| :--- | :---: | :---: | :---: | :--- |
| **`order_id`** | **High** (unique per order) | **Even** (if UUID/random) | **Poor** for customer history; queries by `customer_id` must scatter-gather across all shards. | **Not Recommended** — common user lookups (`find({customer_id})`) broadcast to every shard. |
| **`customer_id`** | **High** (many customers) | **Potentially Uneven** (power/enterprise buyers create jumbo chunks & shard skew) | **Good** — customer-scoped order queries route directly to one shard. | **Secondary Option** — risk of chunk imbalance from heavy buyers. |
| **`order_date`** | **Medium–Low** (coarser timestamps) | **Very Poor (Hotspot)** — monotonically increasing writes hit the single shard owning `MaxKey`. | **Good** for date-range analytics, poor for customer lookups. | **Rejected** — severe write bottleneck on the highest chunk range. |
| **`hashed customer_id`** (`{customer_id: "hashed"}`) | **High** | **Even** — Hashing disperses distinct customer IDs. A single heavy customer still maps to one shard. | **Good** — equality queries on `customer_id` target a single shard via the hashed index. | **Recommended** — balances even cluster-wide write distribution with targeted single-shard customer queries. |

### 2. Activity 11.1: MongoDB 5.0+ Live Resharding (`reshardCollection`)
Starting in MongoDB 5.0+, `db.adminCommand({ reshardCollection: "<db>.<collection>", key: <newShardKey> })` lets you change a collection's shard key while the cluster serves traffic during the copy phase:
1. **Steps:**
   1. Check feature compatibility, index constraints, free space, and oplog headroom.
   2. Run `reshardCollection` against the `admin` database on `mongos`.
   3. MongoDB initializes empty recipient chunks across shards, clones all existing documents in parallel, continuously tails and applies ongoing oplog changes (`applyOps`) so writes stay live, and performs a brief critical-section metadata switchover (~seconds) before dropping the old collection copy.
2. **Key Limitations:**
   - Requires significant temporary disk headroom (~1.2x–2x existing collection + index size across shards) during cloning.
   - Only one resharding operation can run cluster-wide at a time.
   - Cannot reshard collections with `unique` indexes unless the unique key is a prefix of the new shard key.
   - Long-running transactions or heavy write bursts can extend or abort the brief critical-section commit phase if `reshardingCriticalSectionTimeoutMillis` is exceeded.

---

## Lab 11.2: Shard Key Hotspot Detection

### How to Run
1. Start the sharded cluster (`configsvr`, `shardA`, `shardB`, `mongos`):
   ```bash
   docker-compose -f docker-compose.sharded.yml up -d
   ```
2. Initiate each replica set and register shards on `mongos` (`init_sharded_cluster.js`).
3. Run the 10,000-document comparison and `explain()` benchmark:
   ```bash
   python shard_hotspot_experiment.py
   ```

### Findings to record: Ranged vs. Hashed Shard Keys
- **Data Distribution (`collStats`):**
  - `db.hotspot_data` (`{ts: 1}`): The initial ranged collection may place the entire small batch on one shard. As time increases, monotonically increasing `ISODate` timestamps always route to the single chunk holding the upper range (`MaxKey`), capping insert throughput to one shard.
  - `db.even_data` (`{user_id: "hashed"}`): Expect a more even distribution when the empty hashed collection is presplit. Record the observed split.
- **Query Routing (`explain()`):**
  - `db.hotspot_data.find({ts: {$gte: ISODate("2025-01-01"), $lt: ISODate("2025-12-31")}})` executes a **targeted query** to the specific shard(s) owning that timestamp range.
  - `db.even_data.find({user_id: {$gte: ..., $lt: ...}})` triggers a **scatter-gather broadcast** across all shards because hashing destroys natural sort order.
- **When a Ranged Shard Key Is Still Appropriate:** Use a ranged shard key when the key is **not monotonically increasing** (e.g., compound key `{tenant_id: 1, ts: 1}` or `{region: 1, customer_id: 1}`) AND your workload relies heavily on **range scans** (`$gte` / `$lt`), sorting by the shard key, or **Zone Sharding** (pinning geographic/tenant ranges to specific hardware shards).

---

## Lab 12.1 · Collection-scoped authentication and RBAC

Start a fresh local `mongod --auth --bind_ip 127.0.0.1 --port 27017 --dbpath <lab-data-directory>`. Set `LAB12_ADMIN_PASSWORD`, `LAB12_READ_PASSWORD`, `LAB12_WRITE_PASSWORD`, `LAB12_STAFF_PASSWORD`, and `LAB12_HR_PASSWORD`. For the initial run set `LAB12_BOOTSTRAP=1` so the script can create the first admin via the localhost exception. Unset it on subsequent runs.

```sh
mongosh mongodb://127.0.0.1:27017 --file lab12_rbac_and_views.js
```

The reader can find and aggregate orders using the `find` privilege. The writer can find, insert, update, and remove orders. The script tests both permitted and denied operations, including non-HR access to the salary-free view and direct salary access for HR.

## Lab 12.2 · TLS in transit

The self-signed root CA signs both leaf certificates. The server certificate includes localhost and 127.0.0.1 as SANs. The client presents its signed certificate. Keep the generated private keys in the lab directory.

```sh
python tls_cert_manager_and_test.py generate
mongod --bind_ip 127.0.0.1 --port 27017 --dbpath <lab-data-directory> --tlsMode requireTLS --tlsCertificateKeyFile tls_certs/server.pem --tlsCAFile tls_certs/ca.crt
# In another terminal:
python tls_cert_manager_and_test.py verify
```

The verifier attempts a plaintext ping, checks that it is rejected, then checks the CA, hostname, and encrypted read. To combine TLS with the authenticated instance from Lab 12.1, add `--auth` to mongod and run the verifier with `--username app_user_read` and its environment password.

## Lab 13.1 · Authenticated Compose replica set

Run `bash setup_lab13_docker.sh`. The one-shot key initializer creates a shared key in a Docker volume with MongoDB ownership and mode 0400. Each of the three data volumes is separate. All commands for this lab use project `lab13`.

```sh
docker compose -p lab13 -f docker-compose.lab13.yml exec mongo1 mongosh
```

On the current primary, run the following once using the localhost exception. If `db.hello()` identifies another primary, launch mongosh inside that service instead.

```javascript
db.getSiblingDB("admin").createUser({user:"labAdmin", pwd:passwordPrompt(), roles:["root"]})
```

Reconnect using `mongosh -u labAdmin --authenticationDatabase admin -p` and confirm a primary and two healthy secondaries with `rs.status()`. Create a read-only user on `cti_replicated` and insert an example into `cti_replicated.threat_alerts`. Export `MONGO_URI` for the read-only user with percent-encoded credentials, Docker service hosts `mongo1:27017,mongo2:27017,mongo3:27017`, and `replicaSet=rs0&authSource=cti_replicated`.

```sh
docker compose -p lab13 -f docker-compose.lab13.yml run --rm lab-client lab13_failover_reader.py
```

Step down the current primary from an authenticated shell and compare timestamped read-server logs. For the exporter activity, create an account with `clusterMonitor` on admin and `read` on local. Export its URI in `MONGODB_URI`, using `mongo1:27017` with `authSource=admin&directConnection=true`. Start `docker compose -p lab13 -f docker-compose.lab13.yml --profile metrics up -d mongodb-exporter` and query `http://127.0.0.1:9216/metrics`. The lab topology provides authentication and persistence on a single Docker host.

## Lab 13.2 · Kubernetes StatefulSet

Create one shared Secret before starting the pods. An init container in each pod copies the same key to its local emptyDir and restricts its ownership and mode. Per-pod persistent data is stored separately in PVCs. This preserves authentication after rescheduling.

```sh
openssl rand -base64 756 | kubectl create secret generic mongo-replica-key --from-file=keyfile=/dev/stdin
kubectl apply -f mongo-headless-svc.yaml -f mongo-statefulset.yaml
kubectl rollout status statefulset/mongo --timeout=5m
kubectl exec -it mongo-0 -- mongosh
```

```javascript
rs.initiate({_id:"rs0", members:[
  {_id:0,host:"mongo-0.mongo-headless-svc:27017"},
  {_id:1,host:"mongo-1.mongo-headless-svc:27017"},
  {_id:2,host:"mongo-2.mongo-headless-svc:27017"}
]})
```

Create the first admin in a local shell on the elected primary as in Lab 13.1. Authenticate, seed an example, record each member's state and the `mongo-2` claim, then run `kubectl delete pod mongo-2` in this lab namespace. Wait for the replacement and verify its prior PVC, healthy `SECONDARY` status, and replicated data. Kubernetes preserves ordinal DNS names and reattaches PVCs when rescheduling. Compose provides named volumes and restart policies within its Docker host. Kubernetes also requires cluster DNS, a StorageClass, scheduling policies, and Secret management.

## Lab 14.1: Build a Monitoring Dashboard & Activity 14.1 (Webhook Alerting)

### How to Run
```bash
# Poll every 30s, log formatted tables to metrics.log, and send Slack/Discord webhook alerts on breach
python mongodb_monitor_dashboard.py --uri "mongodb://localhost:27017,localhost:27018,localhost:27019/?replicaSet=rs0" \
  --log-file metrics.log --interval 30 --webhook-url "https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
```

### Monitored Metrics & Alerting Thresholds
- **Connection Count:** `serverStatus.connections.current` and `serverStatus.connections.available`.
- **Opcounters:** `insert`, `query`, `update`, `delete`, and `command` totals from `serverStatus.opcounters`.
- **WiredTiger Cache Statistics:** Cache usage (`bytes currently in the cache` vs `maximum bytes configured`) and cache hit ratio (`(pages requested - pages read into cache) / pages requested`).
- **Replica Set Status & Replication Lag:** Member roles (`PRIMARY`/`SECONDARY`) and maximum secondary `optimeDate` lag behind Primary via `replSetGetStatus`.
- **Threshold Alerts & Webhook (Activity 14.1):** Triggers `WARNING` to stdout, appends to `metrics.log`, and dispatches an HTTP `POST` JSON payload via `requests.post(webhook_url, json=alert_payload)` if **Cache Hit Ratio < 80%** or **Replication Lag > 10 seconds**.

---

## Lab 14.2: Automated Backup, Retention Policy, Restore Verification & RPO/RTO

### How to Run
```bash
# 1. Insert 1,000 test docs, take backup, corrupt data, restore via mongorestore --drop, and assert integrity
python backup_verify.py --uri "mongodb://localhost:27017/" --out ./mongo_backups --mode verify

# 2. Benchmark backup & restore times across 1,000, 10,000, and 100,000 documents
python backup_verify.py --uri "mongodb://localhost:27017/" --out ./mongo_backups --mode benchmark

# 3. Start hourly scheduled backups with 7-day retention cleanup
python backup_verify.py --uri "mongodb://localhost:27017/" --out ./mongo_backups --mode schedule
```

### Example backup and restore targets (illustrative)

| Dataset Volume | Approximate Size | `mongodump` Time | `mongorestore` Time | App Restart & Check | Total RTO | RPO (Hourly Schedule) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **1,000 documents** | ~0.95 MB (< 1 MB) | ~0.22 s | ~0.35 s | ~15.00 s | **~15.35 s** | **60 minutes (1 hour)** |
| **10,000 documents** | ~9.8 MB (~10 MB) | ~0.68 s | ~1.05 s | ~15.00 s | **~16.05 s** | **60 minutes (1 hour)** |
| **100,000 documents** | ~98.5 MB (~100 MB) | **~3.80 s** (3–5 s) | **~6.20 s** (5–8 s) | ~15.00 s | **~21.20 s** | **60 minutes (1 hour)** |

- **Recovery Point Objective (RPO):** With `schedule.every().hour.do(run_backup)`, the maximum potential data loss window between backups is **1 hour (60 minutes)** (or near-zero if combined with continuous oplog tailing/PITR).
- **Recovery Time Objective (RTO):** Calculated as `RTO = mongorestore_duration + application_reconnection_and_verification_time`. For 100,000 documents (~100 MB), restore takes ~5–8 seconds plus ~15 seconds for application restart and integrity checks, yielding an **RTO under 25 seconds**.

---

## Lab 15.1: Design a Multi-Tenant API & Activity 15.1 (RBAC)

### How to Run
```bash
pip install fastapi uvicorn pyjwt pymongo pydantic
uvicorn multi_tenant_api:app --reload --port 8000
```

### Architecture & Security Design

Set JWT_SECRET to at least 32 random bytes and LAB_TOKEN_ISSUER_KEY to a separate operator secret before starting the server. Include the operator value in the X-Lab-Token-Key header when requesting a demo JWT. The endpoint checks that the user and role already exist within the requested tenant.
- **Document-Level Tenant Isolation Schema (`tasks`):**
  ```json
  {
    "task_id": "TSK-A1B2C3D4",
    "tenant_id": "tenant_alpha",
    "owner_id": "u_alpha_alice",
    "title": "Rotate API Signing Keys",
    "description": "Quarterly key rotation",
    "status": "IN_PROGRESS",
    "priority": "HIGH",
    "created_at": "2026-11-21T12:00:00Z"
  }
  ```
- **Compound Indexes:** `(tenant_id, created_at)` and `(tenant_id, owner_id)` ensure all tenant-filtered queries use index bounds without scanning other tenants' documents.
- **JWT Tenant Extraction Dependency (`get_current_tenant_user`):** Decodes the Bearer JWT and injects `TenantUserContext(user_id, tenant_id, role)` into every endpoint so `tenant_id` is never trusted from client query/body parameters.
- **Atomic MongoDB Rate Limiting (`enforce_tenant_rate_limit`):** Uses a `rate_limits` collection with a TTL index on `window_expires_at` (`expireAfterSeconds: 0`) and `find_one_and_update(..., {"$inc": {"count": 1}}, upsert=True, return_document=ReturnDocument.AFTER)` to atomically enforce per-tenant request quotas (HTTP `429` when exceeded).
- **Activity 15.1 Role-Based Access Control (RBAC):**
  - **`admin` role:** Queries filter by `{"tenant_id": ctx.tenant_id}` — full CRUD across all tasks in their tenant.
  - **`member` (regular user) role:** Queries filter by `{"tenant_id": ctx.tenant_id, "owner_id": ctx.user_id}` — can only view, create, update, and delete their own tasks.

---

## Lab 15.2: Data Migration Between Tenant Isolation Strategies

### How to Run
```bash
python tenant_migration_benchmark.py --uri "mongodb://localhost:27017/" --db cti_tenant_migration
```

### Migration Pipeline & Leakage Validation
- Seeds **5 tenants** (`t01`–`t05`) with **100 tasks each** (500 total documents) into `tasks`.
- Migrates each tenant into `tasks_tenant_{tenant_id}` via `db.tasks.aggregate([{"$match": {"tenant_id": tid}}, {"$out": f"tasks_tenant_{tid}"}])`.
- Asserts `target_coll.count_documents({}) == 100` and `target_coll.count_documents({"tenant_id": {"$ne": tid}}) == 0` (zero cross-tenant leakage).

### Illustrative performance comparison and architectural recommendation

| Operation | Document-Level Isolation (`tasks` + `{tenant_id, created_at}`) | Collection-Per-Tenant (`tasks_tenant_{tid}`) | Analysis |
| :--- | :---: | :---: | :--- |
| **List Tenant Tasks (50 docs)** | ~0.42 ms | ~0.35 ms | Slightly faster in dedicated collections due to smaller per-collection B-tree indexes and zero multi-tenant index contention. |
| **Create Single Task** | ~0.38 ms | ~0.36 ms | Nearly identical; dedicated collections avoid multi-index lock contention under extreme per-tenant write bursts. |
| **Cross-Tenant Analytics (5 tenants)** | **~0.55 ms** (single `$group`) | ~1.85 ms (`$unionWith` chain) | Document-level isolation is **3x–10x faster** for SaaS-wide BI/reporting because it scans one collection instead of chaining `$unionWith` across hundreds/thousands of collections. |

### When Each Strategy Is Appropriate

| Architectural Dimension | Choose **Document-Level Isolation** (`tenant_id` field) | Choose **Collection-Per-Tenant** (`tasks_tenant_{tid}`) |
| :--- | :--- | :--- |
| **Tenant Scale & Tier** | **Hundreds to 100,000+ SMB / self-serve tenants** (avoids WiredTiger catalog & file-descriptor overhead from too many collections). | **Tens to a few hundred Enterprise tenants** with heavy workloads ("noisy neighbor" isolation) or strict compliance boundaries. |
| **Query Isolation** | Application middleware/JWT dependency must enforce `tenant_id` on every filter; efficient via compound `(tenant_id, ...)` indexes. | Physical namespace separation (`db.tasks_tenant_t01`); zero risk of a missing `tenant_id` predicate leaking another tenant's rows. |
| **Backup Granularity** | Full-collection `mongodump` requires `--query '{"tenant_id":"t01"}'` for single-tenant restore. | Trivial single-tenant backup and point-in-time restore via `mongodump --collection=tasks_tenant_t01`. |
| **Schema Evolution** | Single schema/index migration updates all tenants at once, but custom per-tenant fields create sparse documents. | Independent indexes, validators, and custom fields per enterprise tenant without impacting other tenants. |

---

## Lab 16.1: Model Data in Three Databases & Activity 16.1 (Hybrid Architecture)

The Northbridge teaching dataset contains six fictional students, six courses, and 12 active enrollments. The MongoDB JSON, Cassandra CSV, and Neo4j model use the same student IDs and course codes. The dashboard and Python dataset demo both use these records.

### Schemas Across MongoDB, Cassandra, and Neo4j
- **MongoDB (Document Model):** `students` documents embed `course_ids` (`["PL310", "CS201"]`) and `courses` documents maintain an embedded roster (`enrolled_students`), enabling single-document reads for student-to-course and course-to-student lookups.
- **Cassandra (Query-Driven Table Design):** Denormalized wide-column tables partitioned by lookup key:
  - `student_courses` with `PRIMARY KEY (student_id, course_id)` to fetch all courses for a student in one partition read.
  - `course_students` with `PRIMARY KEY (course_id, student_id)` to fetch all students enrolled in a course in one partition read.
- **Neo4j (Node & Relationship Graph Model):** `(:Student {student_id, name})` and `(:Course {course_id, title})` nodes linked by `[:ENROLLED_IN]` relationships.

### Equivalent Queries & Complexity / Performance Comparison

| Query / Characteristic | MongoDB | Cassandra | Neo4j (Cypher) |
| :--- | :--- | :--- | :--- |
| **Courses for a Student** | `db.students.findOne({ name: 'Leena Fernandes' }, { course_ids: 1 })` | `SELECT course_id FROM student_courses WHERE student_id = 'NB101';` | `MATCH (s:Student {name: 'Leena Fernandes'})-[:ENROLLED_IN]->(c:Course) RETURN c.name;` |
| **Students in a Course** | `db.courses.findOne({ _id: 'PL310' }, { enrolled_students: 1 })` | `SELECT student_id, student_name FROM course_students WHERE course_id = 'PL310';` | `MATCH (s:Student)-[:ENROLLED_IN]->(c:Course {course_id: 'PL310'}) RETURN s.name;` |
| **Students Sharing a Course** | Requires `$lookup` / self-join aggregation pipeline; more verbose and heavier at scale. | Requires two-step client query (`student_courses` -> `course_students`); Cassandra intentionally avoids cross-partition joins. | Most expressive & natural: `MATCH (s1:Student)-[:ENROLLED_IN]->(c:Course)<-[:ENROLLED_IN]-(s2:Student) WHERE s1.name = 'Leena Fernandes' AND s2.name <> 'Leena Fernandes' RETURN DISTINCT s2.name;` |
| **Expected Performance** | Sub-5 ms single-doc reads; `$lookup` degrades as array/join fan-out grows. | Predictable low-millisecond single-partition reads; scales linearly for high-volume writes. | Fast index-free adjacency traversals for shared-course and multi-hop neighborhood queries. |

### Activity 16.1: Hybrid Architecture Design
- **MongoDB (Operational Data):** Stores core academic entities (`students`, `courses`, `enrollments`) with flexible schema evolution and rich document queries.
- **Cassandra (Audit Logging):** Captures high-throughput, append-only enrollment/grade/access audit events partitioned by `tenant_or_actor_id` and clustered by `event_time DESC` with TTL retention.
- **Neo4j (Prerequisite Chain Queries):** Models `(:Course)-[:PREREQUISITE_OF]->(:Course)` edges to run variable-length path traversals (`*1..5`) for prerequisite eligibility and degree planning.

---

## Lab 16.2: Build a Hybrid Query Service (`FraudQueryService`)

### How to Run Unit & Integration Tests
```bash
python -m unittest discover -s . -p "test_*.py" -v
```

### Architecture, Connection Pooling & Circuit Breaker
- **`get_transaction(txn_id)` (MongoDB):** Uses `MongoClient(..., maxPoolSize=10)` and queries `db.transactions.find_one({"txn_id": txn_id})` for flexible document retrieval (`amount`, `merchant`, `timestamp`, `risk_score`).
- **`get_user_profile(user_id)` (Cassandra):** Uses `Cluster(..., executor_threads=4)` and runs `SELECT * FROM user_profiles WHERE user_id = ? ORDER BY event_time DESC LIMIT 10` for time-ordered event history.
- **`detect_fraud_rings(user_id, max_hops=3)` (Neo4j):** Uses `GraphDatabase.driver(..., max_connection_pool_size=10)` and runs `MATCH path = (u:User {id: $uid})-[:TRANSFERRED_TO*1..3]-(connected:User) RETURN path LIMIT 50` for multi-hop graph traversal.
- **Circuit Breaker:** Tracks consecutive errors per backend; opens after **3 consecutive failures**, skips calls while open, and transitions to `HALF_OPEN` for a retry after **30 seconds**.
- **Documented Latency Characteristics:**
  - **MongoDB lookups:** ~2 to 5 ms
  - **Cassandra time-ordered queries:** ~3 to 8 ms
  - **Neo4j graph traversals:** ~10 ms (1 hop) up to ~500 ms (3 hops), varying with graph density and fan-out.


---

## Lab 17.1 · Atlas RAG and conversation memory

Set `MONGO_URI`, `VOYAGE_API_KEY`, and `OPENAI_API_KEY`. Use a disposable Atlas database with permission to create Vector Search indexes.

```sh
python lab17_vector_search_rag/lab17_1_rag_pipeline_with_memory.py --ingest --user demo --query "Is a trusted source sufficient evidence?" --query "What should I verify next?"
```

The script creates overlapping windows of up to 100 words, stores their embeddings, waits for the vector index, retrieves up to three chunks with `numCandidates=20`, and supplies the last five exchanges for the chosen lab user. The user identifier is a CLI namespace. For a shared app, derive it from authenticated identity.

## Lab 17.2 · HNSW and IVF comparison

Atlas documents HNSW and flat index methods. The proposed IVF `indexOption` and `nprobe` syntax is unavailable in the documented Atlas API. This lab uses FAISS for both algorithms, while Lab 17.1 uses Atlas. FAISS isolates algorithm trade-offs and produces local timings that omit database and network overhead. [MongoDB Vector Search index definitions](https://www.mongodb.com/docs/vector-search/indexes/vector-search-type/)

```sh
python lab17_vector_search_rag/lab17_2_hnsw_vs_ivf_benchmark.py corpus.txt
```

Supply at least 5,100 distinct sentences, one per line. The runner uses 5,000 indexed 384-dimensional embeddings and 100 held-out queries. It reports build time, average latency, and Recall@20 against exact cosine results. It sweeps HNSW graph construction and search parameters and IVF list and probe counts, writing `vector_benchmark.csv` and `latency_recall.png`. Compare configurations at the same recall target. Use observed data to justify the latency and build cost trade-offs.

## Lab 18.1 · Comparative system

See [LAB18_COMPARATIVE_REPORT.md](LAB18_COMPARATIVE_REPORT.md) for the feed input format, benchmark commands, and report.

